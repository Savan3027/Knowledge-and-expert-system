from openai import OpenAI

llm = OpenAI(
    api_key = "sk-proj-UMyAS2Pr66RML1aalhQtT3BlbkFJ8DiOWalJnyj28C5ZaMOx",
    base_url = "http://localhost:1234/v1"
)

system_prompt = "Give me a description for the following course title"
user_input = "AIDI 2001 Expert Systems"

response = llm.chat.completions.create(
    model = "gpt-3.5-turbo",
    max_tokens = 100,
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content":user_input}
    ]
)

print(response.choices[0].message.content)